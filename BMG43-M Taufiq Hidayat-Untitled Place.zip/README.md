# BMG43-M-Taufiq-Hidayat-Untitled-Place
 
